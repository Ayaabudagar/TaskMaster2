package com.example.TaskMaster;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CodeChallenges401 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_challenges401);
    }
}